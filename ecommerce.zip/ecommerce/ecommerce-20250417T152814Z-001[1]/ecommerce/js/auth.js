document.addEventListener('DOMContentLoaded', function() {
    // Initialize cart count
    initCart();
    
    // Handle login form submission
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleLogin();
        });
    }
    
    // Handle register form submission
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleRegistration();
        });
    }
    
    // Check if user is logged in
    checkAuthStatus();
});

// Function to handle login
function handleLogin() {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    const rememberMe = document.getElementById('remember-me').checked;
    const errorElement = document.getElementById('login-error');
    
    // Clear previous error
    errorElement.style.display = 'none';
    
    // Get users from localStorage
    const users = JSON.parse(localStorage.getItem('users')) || [];
    
    // Find user with matching email
    const user = users.find(u => u.email === email);
    
    // Check if user exists and password matches (in a real app, this would use secure authentication)
    if (!user || user.password !== password) {
        errorElement.textContent = 'Invalid email or password.';
        errorElement.style.display = 'block';
        return;
    }
    
    // Store auth status in localStorage
    const authData = {
        isLoggedIn: true,
        user: {
            firstName: user.firstName,
            lastName: user.lastName,
            email: user.email
        },
        expiry: rememberMe ? null : new Date().getTime() + (24 * 60 * 60 * 1000) // 24 hours if not remember me
    };
    
    localStorage.setItem('authData', JSON.stringify(authData));
    
    // Redirect to home page
    window.location.href = 'index.html';
}

// Function to handle registration
function handleRegistration() {
    const firstName = document.getElementById('register-firstname').value;
    const lastName = document.getElementById('register-lastname').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const confirmPassword = document.getElementById('register-confirm-password').value;
    const agreeTerms = document.getElementById('agree-terms').checked;
    const errorElement = document.getElementById('register-error');
    
    // Clear previous error
    errorElement.style.display = 'none';
    
    // Validate password
    if (password.length < 8) {
        errorElement.textContent = 'Password must be at least 8 characters long.';
        errorElement.style.display = 'block';
        return;
    }
    
    if (!/\d/.test(password)) {
        errorElement.textContent = 'Password must include at least one number.';
        errorElement.style.display = 'block';
        return;
    }
    
    if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
        errorElement.textContent = 'Password must include at least one special character.';
        errorElement.style.display = 'block';
        return;
    }
    
    // Check if passwords match
    if (password !== confirmPassword) {
        errorElement.textContent = 'Passwords do not match.';
        errorElement.style.display = 'block';
        return;
    }
    
    // Check terms agreement
    if (!agreeTerms) {
        errorElement.textContent = 'You must agree to the Terms and Conditions.';
        errorElement.style.display = 'block';
        return;
    }
    
    // Get existing users from localStorage
    const users = JSON.parse(localStorage.getItem('users')) || [];
    
    // Check if email already exists
    if (users.some(user => user.email === email)) {
        errorElement.textContent = 'Email already exists. Please use a different email address.';
        errorElement.style.display = 'block';
        return;
    }
    
    // Add new user
    const newUser = {
        firstName,
        lastName,
        email,
        password, // In a real app, this would be hashed
        createdAt: new Date().toISOString()
    };
    
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    
    // Auto login the new user
    const authData = {
        isLoggedIn: true,
        user: {
            firstName: newUser.firstName,
            lastName: newUser.lastName,
            email: newUser.email
        },
        expiry: null
    };
    
    localStorage.setItem('authData', JSON.stringify(authData));
    
    // Redirect to home page
    window.location.href = 'index.html';
}

// Function to check auth status
function checkAuthStatus() {
    const authData = JSON.parse(localStorage.getItem('authData'));
    
    // If no auth data or not logged in
    if (!authData || !authData.isLoggedIn) {
        return false;
    }
    
    // Check if session has expired
    if (authData.expiry && new Date().getTime() > authData.expiry) {
        // Clear expired session
        localStorage.removeItem('authData');
        return false;
    }
    
    // User is logged in
    return true;
}

// Function to log out
function logOut() {
    localStorage.removeItem('authData');
    window.location.href = 'login.html';
} 