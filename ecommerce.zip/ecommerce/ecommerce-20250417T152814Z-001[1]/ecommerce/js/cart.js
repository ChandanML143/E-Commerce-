document.addEventListener('DOMContentLoaded', function() {
    // Initialize cart
    initCart();
    
    // Display cart contents
    displayCart();
    
    // Event listener for clearing cart
    const clearCartButton = document.getElementById('clear-cart');
    if (clearCartButton) {
        clearCartButton.addEventListener('click', function() {
            clearCart();
            displayCart();
            
            // Show notification
            showNotification('Cart has been cleared', 'info');
        });
    }
});

// Function to display cart contents
function displayCart() {
    const cart = getCart();
    const emptyCartElement = document.getElementById('empty-cart');
    const cartItemsElement = document.getElementById('cart-items');
    const cartProductsElement = document.getElementById('cart-products');
    
    // Check if cart is empty
    if (cart.length === 0) {
        emptyCartElement.style.display = 'block';
        cartItemsElement.style.display = 'none';
        return;
    }
    
    // Cart has items
    emptyCartElement.style.display = 'none';
    cartItemsElement.style.display = 'block';
    
    // Clear previous cart items
    cartProductsElement.innerHTML = '';
    
    // Add cart items
    cart.forEach(item => {
        const cartItemHTML = createCartItemHTML(item);
        cartProductsElement.innerHTML += cartItemHTML;
    });
    
    // Add event listeners to quantity buttons and remove buttons
    addCartEventListeners();
    
    // Update cart summary
    updateCartSummary();
}

// Function to create HTML for a cart item
function createCartItemHTML(item) {
    return `
        <div class="cart-item" data-id="${item.id}">
            <div class="row align-items-center">
                <div class="col-md-2 col-4">
                    <img src="${item.image}" alt="${item.name}" class="img-fluid cart-item-img">
                </div>
                <div class="col-md-4 col-8 cart-item-details">
                    <h5>${item.name}</h5>
                    <p class="text-primary">₹${item.price.toFixed(2)}</p>
                </div>
                <div class="col-md-3 col-6 mt-2 mt-md-0">
                    <div class="quantity-selector">
                        <button class="quantity-decrease" data-id="${item.id}">-</button>
                        <input type="number" class="cart-quantity" value="${item.quantity}" min="1" data-id="${item.id}">
                        <button class="quantity-increase" data-id="${item.id}">+</button>
                    </div>
                </div>
                <div class="col-md-2 col-3 mt-2 mt-md-0 text-center">
                    <p class="fw-bold">₹${(item.price * item.quantity).toFixed(2)}</p>
                </div>
                <div class="col-md-1 col-3 mt-2 mt-md-0 text-end">
                    <button class="btn btn-sm btn-outline-danger remove-item" data-id="${item.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        </div>
        <hr>
    `;
}

// Function to add event listeners to cart elements
function addCartEventListeners() {
    // Quantity decrease buttons
    const decreaseButtons = document.querySelectorAll('.quantity-decrease');
    decreaseButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productId = parseInt(this.getAttribute('data-id'));
            const currentQuantity = getCurrentCartItemQuantity(productId);
            
            if (currentQuantity > 1) {
                updateCartItemQuantity(productId, currentQuantity - 1);
                displayCart();
                showNotification('Cart updated', 'info');
            }
        });
    });
    
    // Quantity increase buttons
    const increaseButtons = document.querySelectorAll('.quantity-increase');
    increaseButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productId = parseInt(this.getAttribute('data-id'));
            const currentQuantity = getCurrentCartItemQuantity(productId);
            
            updateCartItemQuantity(productId, currentQuantity + 1);
            displayCart();
            showNotification('Cart updated', 'info');
        });
    });
    
    // Quantity input fields
    const quantityInputs = document.querySelectorAll('.cart-quantity');
    quantityInputs.forEach(input => {
        input.addEventListener('change', function() {
            const productId = parseInt(this.getAttribute('data-id'));
            const newQuantity = parseInt(this.value);
            
            if (newQuantity > 0) {
                updateCartItemQuantity(productId, newQuantity);
                displayCart();
                showNotification('Cart updated', 'info');
            } else {
                // Reset to 1 if invalid input
                this.value = 1;
            }
        });
    });
    
    // Remove buttons
    const removeButtons = document.querySelectorAll('.remove-item');
    removeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productId = parseInt(this.getAttribute('data-id'));
            removeFromCart(productId);
            displayCart();
            showNotification('Item removed from cart', 'info');
        });
    });
}

// Function to get current quantity of a cart item
function getCurrentCartItemQuantity(productId) {
    const cart = getCart();
    const item = cart.find(item => item.id === productId);
    return item ? item.quantity : 0;
}

// Function to update cart summary
function updateCartSummary() {
    const subtotal = calculateCartTotal();
    const shipping = subtotal > 0 ? 10 : 0; // ₹10 shipping if cart has items
    const tax = subtotal * 0.08; // 8% tax
    const total = subtotal + shipping + tax;
    
    // Update summary elements
    document.getElementById('cart-subtotal').textContent = `₹${subtotal.toFixed(2)}`;
    document.getElementById('cart-shipping').textContent = `₹${shipping.toFixed(2)}`;
    document.getElementById('cart-tax').textContent = `₹${tax.toFixed(2)}`;
    document.getElementById('cart-total').textContent = `₹${total.toFixed(2)}`;
    
    // Store total in localStorage for checkout
    localStorage.setItem('cartTotal', total.toFixed(2));
    localStorage.setItem('cartSubtotal', subtotal.toFixed(2));
    localStorage.setItem('cartShipping', shipping.toFixed(2));
    localStorage.setItem('cartTax', tax.toFixed(2));
}

// Function to show notification
function showNotification(message, type = 'success') {
    const toastContainer = document.getElementById('toast-container');
    if (toastContainer) {
        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white bg-${type} border-0`;
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');
        toast.setAttribute('aria-atomic', 'true');
        
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    <i class="fas fa-${type === 'success' ? 'check' : 'info'}-circle me-2"></i>${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        `;
        
        toastContainer.appendChild(toast);
        
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
        
        // Remove toast after it's hidden
        toast.addEventListener('hidden.bs.toast', function() {
            toast.remove();
        });
    }
}

// Function to clear the cart
function clearCart() {
    localStorage.setItem('cart', JSON.stringify([]));
    updateCartCount();
} 