document.addEventListener('DOMContentLoaded', function() {
    // Initialize cart count
    initCart();
    
    // Display order summary
    displayOrderSummary();
    
    // Set up payment method selection
    setupPaymentMethodSelection();
    
    // Handle checkout form submission
    const checkoutForm = document.getElementById('checkout-form');
    if (checkoutForm) {
        checkoutForm.addEventListener('submit', function(e) {
            e.preventDefault();
            processOrder();
        });
    }
});

// Function to display order summary
function displayOrderSummary() {
    const cart = getCart();
    const checkoutItemsContainer = document.getElementById('checkout-items');
    
    // Check if cart is empty
    if (cart.length === 0) {
        // Redirect to cart page if cart is empty
        window.location.href = 'cart.html';
        return;
    }
    
    // Clear previous items
    checkoutItemsContainer.innerHTML = '';
    
    // Add order items to summary
    cart.forEach(item => {
        const itemHTML = `
            <div class="d-flex justify-content-between align-items-center mb-2">
                <div>
                    <span class="fw-bold">${item.quantity} x</span> ${item.name}
                </div>
                <span>₹${(item.price * item.quantity).toFixed(2)}</span>
            </div>
        `;
        checkoutItemsContainer.innerHTML += itemHTML;
    });
    
    // Update summary totals
    updateOrderSummary();
}

// Function to update order summary totals
function updateOrderSummary() {
    // Get values from localStorage (set in cart.js)
    const subtotal = localStorage.getItem('cartSubtotal') || '0.00';
    const shipping = localStorage.getItem('cartShipping') || '0.00';
    const tax = localStorage.getItem('cartTax') || '0.00';
    const total = localStorage.getItem('cartTotal') || '0.00';
    
    // Update UI
    document.getElementById('checkout-subtotal').textContent = `₹${subtotal}`;
    document.getElementById('checkout-shipping').textContent = `₹${shipping}`;
    document.getElementById('checkout-tax').textContent = `₹${tax}`;
    document.getElementById('checkout-total').textContent = `₹${total}`;
}

// Function to set up payment method selection
function setupPaymentMethodSelection() {
    const paymentRadios = document.querySelectorAll('input[name="payment-method"]');
    const creditCardDetails = document.getElementById('credit-card-details');
    const paymentCards = document.querySelectorAll('.payment-card');
    
    // Add selected class to the initial selected payment card
    paymentCards.forEach(card => {
        if (card.dataset.payment === 'credit-card') {
            card.classList.add('selected');
        }
    });
    
    // Show/hide credit card details based on selected payment method
    paymentRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            // Remove selected class from all payment cards
            paymentCards.forEach(card => {
                card.classList.remove('selected');
            });
            
            // Add selected class to the current payment card
            const selectedCard = document.querySelector(`.payment-card[data-payment="${this.value}"]`);
            if (selectedCard) {
                selectedCard.classList.add('selected');
            }
            
            // Show/hide credit card details
            if (this.value === 'credit-card') {
                creditCardDetails.style.display = 'block';
            } else {
                creditCardDetails.style.display = 'none';
            }
        });
    });
}

// Function to process the order
function processOrder() {
    // Get form data
    const firstName = document.getElementById('first-name').value;
    const lastName = document.getElementById('last-name').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const address = document.getElementById('address').value;
    const address2 = document.getElementById('address2').value;
    const country = document.getElementById('country').value;
    const state = document.getElementById('state').value;
    const zip = document.getElementById('zip').value;
    
    // Get payment method
    const paymentMethod = document.querySelector('input[name="payment-method"]:checked').value;
    
    // Get order details
    const cart = getCart();
    const total = localStorage.getItem('cartTotal') || '0.00';
    
    // Create order object (would normally be sent to a server)
    const order = {
        customer: {
            firstName,
            lastName,
            email,
            phone
        },
        shipping: {
            address,
            address2,
            country,
            state,
            zip
        },
        payment: {
            method: paymentMethod,
            // If using credit card, would include card details (in a real app would be processed securely)
        },
        items: cart,
        total: parseFloat(total),
        orderDate: new Date().toISOString(),
        orderNumber: generateOrderNumber()
    };
    
    // For demo purposes, store the order in localStorage
    const orders = JSON.parse(localStorage.getItem('orders')) || [];
    orders.push(order);
    localStorage.setItem('orders', JSON.stringify(orders));
    
    // Clear the cart
    clearCart();
    
    // Store order number for confirmation page
    localStorage.setItem('lastOrderNumber', order.orderNumber);
    
    // Redirect to confirmation page
    window.location.href = 'order-confirmation.html';
}

// Function to generate a random order number
function generateOrderNumber() {
    const timestamp = new Date().getTime().toString().slice(-8);
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    return `ORD-${timestamp}-${random}`;
} 