document.addEventListener('DOMContentLoaded', function() {
    // Initialize cart count
    initCart();
    
    // Display order details
    displayOrderConfirmation();
});

function displayOrderConfirmation() {
    // Get order number from localStorage
    const orderNumber = localStorage.getItem('lastOrderNumber') || 'ORD-12345678';
    document.getElementById('order-number').textContent = orderNumber;
    
    // Get order totals from localStorage
    const subtotal = localStorage.getItem('cartSubtotal') || '0.00';
    const shipping = localStorage.getItem('cartShipping') || '0.00';
    const tax = localStorage.getItem('cartTax') || '0.00';
    const total = localStorage.getItem('cartTotal') || '0.00';
    
    // Update UI
    document.getElementById('confirmation-subtotal').textContent = `₹${subtotal}`;
    document.getElementById('confirmation-shipping').textContent = `₹${shipping}`;
    document.getElementById('confirmation-tax').textContent = `₹${tax}`;
    document.getElementById('confirmation-total').textContent = `₹${total}`;
    
    // Get the most recent order from localStorage
    const orders = JSON.parse(localStorage.getItem('orders')) || [];
    const lastOrder = orders.length > 0 ? orders[orders.length - 1] : null;
    
    // If we have order details, populate the page with them
    if (lastOrder) {
        // Shipping info
        const shipping = lastOrder.shipping;
        const customer = lastOrder.customer;
        
        if (shipping && customer) {
            const shippingInfoElement = document.querySelector('.col-md-6:first-child');
            
            if (shippingInfoElement) {
                const shippingHtml = `
                    <h5>Shipping Information</h5>
                    <p class="mb-1">${customer.firstName} ${customer.lastName}</p>
                    <p class="mb-1">${shipping.address}</p>
                    ${shipping.address2 ? `<p class="mb-1">${shipping.address2}</p>` : ''}
                    <p class="mb-1">${shipping.state}, ${shipping.zip}</p>
                    <p>${shipping.country}</p>
                    
                    <h5 class="mt-4">Shipping Method</h5>
                    <p>Standard Shipping (5-7 business days)</p>
                `;
                
                shippingInfoElement.innerHTML = shippingHtml;
            }
        }
        
        // Payment info
        const payment = lastOrder.payment;
        
        if (payment) {
            const paymentInfoElement = document.querySelector('.col-md-6:nth-child(2) h5:first-of-type + p');
            
            if (paymentInfoElement) {
                paymentInfoElement.textContent = `Payment Method: ${payment.method === 'credit-card' ? 'Credit Card' : 'PayPal'}`;
            }
        }
    }
} 