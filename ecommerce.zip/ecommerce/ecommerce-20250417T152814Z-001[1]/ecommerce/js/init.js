document.addEventListener('DOMContentLoaded', function() {
    // Initialize cart and favorites
    initCart();
    initFavorites();
    
    // Load page-specific content
    if (document.querySelector('.featured-products')) {
        loadFeaturedProducts();
    }
    
    if (document.querySelector('.product-detail-title')) {
        loadProductDetail();
    }
    
    if (document.querySelector('#products-container')) {
        loadProductListing();
    }
    
    // Initialize search form
    const searchForm = document.querySelector('#search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const searchInput = this.querySelector('input[name="search"]');
            if (searchInput.value.trim()) {
                window.location.href = `products.html?search=${encodeURIComponent(searchInput.value.trim())}`;
            }
        });
    }
}); 