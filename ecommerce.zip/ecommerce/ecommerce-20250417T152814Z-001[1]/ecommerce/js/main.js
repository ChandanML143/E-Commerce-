// Favorites Functions
function initFavorites() {
    // Initialize favorites from localStorage or create a new one
    if (!localStorage.getItem('favorites')) {
        localStorage.setItem('favorites', JSON.stringify([]));
    }
}

function getFavorites() {
    return JSON.parse(localStorage.getItem('favorites')) || [];
}

function isProductFavorite(productId) {
    const favorites = getFavorites();
    return favorites.includes(parseInt(productId));
}

function addToFavorites(productId) {
    const favorites = getFavorites();
    if (!favorites.includes(parseInt(productId))) {
        favorites.push(parseInt(productId));
        localStorage.setItem('favorites', JSON.stringify(favorites));
        
        // Show notification
        showNotification(`${getProductById(productId).name} added to favorites!`, 'success');
    }
}

function removeFromFavorites(productId) {
    let favorites = getFavorites();
    favorites = favorites.filter(id => id !== parseInt(productId));
    localStorage.setItem('favorites', JSON.stringify(favorites));
    
    // Show notification
    showNotification(`${getProductById(productId).name} removed from favorites!`, 'info');
}

function showNotification(message, type = 'success') {
    const toastContainer = document.getElementById('toast-container');
    if (toastContainer) {
        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white bg-${type} border-0`;
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');
        toast.setAttribute('aria-atomic', 'true');
        
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    <i class="fas fa-${type === 'success' ? 'check' : 'info'}-circle me-2"></i>${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        `;
        
        toastContainer.appendChild(toast);
        
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
        
        // Remove toast after it's hidden
        toast.addEventListener('hidden.bs.toast', function() {
            toast.remove();
        });
    }
}

// Product Display Functions
function loadFeaturedProducts() {
    const featuredContainer = document.getElementById('featured-products');
    const featuredProducts = getFeaturedProducts();
    
    featuredContainer.innerHTML = '';
    
    featuredProducts.forEach(product => {
        featuredContainer.appendChild(createProductCard(product));
    });
}

function loadProductListing() {
    const productsContainer = document.getElementById('products-container');
    const urlParams = new URLSearchParams(window.location.search);
    let productsList;
    
    // Get products based on URL parameters
    if (urlParams.has('category')) {
        const category = urlParams.get('category');
        productsList = getProductsByCategory(category);
        
        // Update page title
        const categoryTitle = document.getElementById('category-title');
        if (categoryTitle) {
            categoryTitle.textContent = category.charAt(0).toUpperCase() + category.slice(1);
        }
    } else if (urlParams.has('search')) {
        const searchQuery = urlParams.get('search');
        productsList = searchProducts(searchQuery);
        
        // Update page title
        const categoryTitle = document.getElementById('category-title');
        if (categoryTitle) {
            categoryTitle.textContent = `Search Results for "${searchQuery}"`;
        }
    } else {
        productsList = getProductsByCategory('all');
    }
    
    // Apply sorting if specified
    if (urlParams.has('sort')) {
        const sortBy = urlParams.get('sort');
        productsList = sortProducts(productsList, sortBy);
    }
    
    // Apply price range filter if specified
    if (urlParams.has('min-price') && urlParams.has('max-price')) {
        const minPrice = parseFloat(urlParams.get('min-price'));
        const maxPrice = parseFloat(urlParams.get('max-price'));
        productsList = filterByPriceRange(productsList, minPrice, maxPrice);
    }
    
    // Apply rating filter if specified
    if (urlParams.has('rating')) {
        const minRating = parseFloat(urlParams.get('rating'));
        productsList = filterByRating(productsList, minRating);
    }
    
    // Apply in-stock filter if specified
    if (urlParams.has('in-stock')) {
        const inStockOnly = urlParams.get('in-stock') === 'true';
        productsList = filterByAvailability(productsList, inStockOnly);
    }
    
    // Display the products
    productsContainer.innerHTML = '';
    
    if (productsList.length === 0) {
        productsContainer.innerHTML = `
            <div class="col-12">
                <div class="alert alert-info">
                    No products found. Please try a different search or category.
                </div>
            </div>
        `;
        return;
    }
    
    productsList.forEach(product => {
        productsContainer.appendChild(createProductCard(product));
    });
    
    // Set up sorting dropdown
    const sortingDropdown = document.getElementById('sort-by');
    if (sortingDropdown) {
        sortingDropdown.value = urlParams.get('sort') || 'default';
        sortingDropdown.addEventListener('change', function() {
            urlParams.set('sort', this.value);
            window.location.search = urlParams.toString();
        });
    }
    
    // Set up filter form
    const filterForm = document.getElementById('filter-form');
    if (filterForm) {
        // Set initial values based on URL params
        if (urlParams.has('min-price')) {
            filterForm.querySelector('#min-price').value = urlParams.get('min-price');
        }
        if (urlParams.has('max-price')) {
            filterForm.querySelector('#max-price').value = urlParams.get('max-price');
        }
        if (urlParams.has('rating')) {
            const ratingRadio = filterForm.querySelector(`input[name="rating"][value="${urlParams.get('rating')}"]`);
            if (ratingRadio) ratingRadio.checked = true;
        }
        if (urlParams.has('in-stock')) {
            filterForm.querySelector('#in-stock').checked = urlParams.get('in-stock') === 'true';
        }
        
        // Handle form submission
        filterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const minPrice = this.querySelector('#min-price').value;
            const maxPrice = this.querySelector('#max-price').value;
            const ratingRadio = this.querySelector('input[name="rating"]:checked');
            const inStock = this.querySelector('#in-stock').checked;
            
            if (minPrice) urlParams.set('min-price', minPrice);
            else urlParams.delete('min-price');
            
            if (maxPrice) urlParams.set('max-price', maxPrice);
            else urlParams.delete('max-price');
            
            if (ratingRadio) urlParams.set('rating', ratingRadio.value);
            else urlParams.delete('rating');
            
            urlParams.set('in-stock', inStock);
            
            window.location.search = urlParams.toString();
        });
    }
}

function loadProductDetail() {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = parseInt(urlParams.get('id'));
    
    if (!productId) {
        window.location.href = 'index.html';
        return;
    }
    
    const product = getProductById(productId);
    
    if (!product) {
        window.location.href = 'index.html';
        return;
    }
    
    // Update product details
    document.querySelector('.product-detail-img').src = product.image;
    document.querySelector('.product-detail-title').textContent = product.name;
    document.querySelector('.product-detail-price').textContent = `₹${product.price.toFixed(2)}`;
    document.querySelector('.product-detail-description').textContent = product.description;
    
    // Update availability status
    const availabilityEl = document.querySelector('.product-availability');
    if (product.inStock) {
        availabilityEl.textContent = 'In Stock';
        availabilityEl.className = 'product-availability text-success';
    } else {
        availabilityEl.textContent = 'Out of Stock';
        availabilityEl.className = 'product-availability text-danger';
    }
    
    // Update rating
    const ratingEl = document.querySelector('.product-detail-rating');
    ratingEl.innerHTML = generateRatingStars(product.rating);
    ratingEl.innerHTML += `<span class="ms-2">(${product.reviews} reviews)</span>`;
    
    // Add favorite button
    const favoriteContainer = document.querySelector('.product-actions');
    if (favoriteContainer) {
        // Check if product is in favorites
        const isFavorite = isProductFavorite(productId);
        const favoriteBtn = document.createElement('button');
        favoriteBtn.className = 'btn btn-outline-secondary favorite-btn ms-2';
        favoriteBtn.innerHTML = `<i class="${isFavorite ? 'fas fa-heart text-danger' : 'far fa-heart'}"></i> ${isFavorite ? 'Favorited' : 'Add to Favorites'}`;
        
        favoriteBtn.addEventListener('click', function() {
            const icon = this.querySelector('i');
            
            if (isProductFavorite(productId)) {
                removeFromFavorites(productId);
                icon.className = 'far fa-heart';
                this.innerHTML = `<i class="far fa-heart"></i> Add to Favorites`;
            } else {
                addToFavorites(productId);
                icon.className = 'fas fa-heart text-danger';
                this.innerHTML = `<i class="fas fa-heart text-danger"></i> Favorited`;
            }
        });
        
        favoriteContainer.appendChild(favoriteBtn);
    }
    
    // Handle add to cart button
    const addToCartBtn = document.querySelector('#add-to-cart');
    const quantityInput = document.querySelector('#quantity-input');
    
    if (!product.inStock) {
        addToCartBtn.disabled = true;
        addToCartBtn.textContent = 'Out of Stock';
    } else {
        addToCartBtn.addEventListener('click', function() {
            const quantity = parseInt(quantityInput.value);
            if (quantity > 0) {
                const success = addToCart(productId, quantity);
                
                if (success) {
                    // Show success message
                    const alertContainer = document.querySelector('.alert-container');
                    alertContainer.innerHTML = `
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Success!</strong> ${product.name} has been added to your cart.
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    `;
                }
            }
        });
    }
    
    // Handle quantity buttons
    document.querySelector('#quantity-minus').addEventListener('click', function() {
        let qty = parseInt(quantityInput.value);
        if (qty > 0) {
            qty--;
            quantityInput.value = qty;
            
            // If quantity becomes 0, remove item from cart
            if (qty === 0 && isProductInCart(productId)) {
                removeFromCart(productId);
                showNotification(`${product.name} removed from cart`, 'info');
                
                // Update add to cart button text
                addToCartBtn.innerHTML = '<i class="fas fa-shopping-cart me-2"></i>Add to Cart';
            }
        }
    });
    
    document.querySelector('#quantity-plus').addEventListener('click', function() {
        let qty = parseInt(quantityInput.value);
        const newQty = qty + 1;
        quantityInput.value = newQty;
        
        // If increasing from 0, add to cart
        if (qty === 0) {
            const success = addToCart(productId, 1);
            if (success) {
                showNotification(`${product.name} added to cart!`, 'success');
                // Update add to cart button text to show item is in cart
                addToCartBtn.innerHTML = '<i class="fas fa-shopping-cart me-2"></i>Update Cart';
            }
        } else if (isProductInCart(productId)) {
            // Update quantity if already in cart
            updateCartItemQuantity(productId, newQty);
        }
    });
    
    // Load related products
    const relatedProductsContainer = document.querySelector('.related-products');
    const relatedProducts = getRelatedProducts(productId);
    
    relatedProductsContainer.innerHTML = '';
    
    relatedProducts.forEach(product => {
        relatedProductsContainer.appendChild(createProductCard(product));
    });
}

function createProductCard(product) {
    const colDiv = document.createElement('div');
    colDiv.className = 'col-sm-6 col-md-4 col-lg-3';
    
    // Check if product is in favorites
    const isFavorite = isProductFavorite(product.id);
    const favoriteIconClass = isFavorite ? 'fas fa-heart text-danger' : 'far fa-heart';
    
    const cardHTML = `
        <div class="card product-card h-100">
            <div class="position-absolute top-0 end-0 p-2">
                <button class="btn btn-sm btn-light rounded-circle favorite-btn" data-product-id="${product.id}">
                    <i class="${favoriteIconClass}"></i>
                </button>
            </div>
            <img src="${product.image}" class="card-img-top product-image" alt="${product.name}">
            <div class="card-body d-flex flex-column">
                <h5 class="card-title product-title">${product.name}</h5>
                <div class="product-rating mb-2">
                    ${generateRatingStars(product.rating)}
                    <small class="text-muted ms-1">(${product.reviews})</small>
                </div>
                <p class="card-text product-price mb-2">₹${product.price.toFixed(2)}</p>
                <div class="mt-auto">
                    ${product.inStock ? 
                        `<button class="btn btn-primary w-100 add-to-cart-btn" data-product-id="${product.id}">
                            <i class="fas fa-shopping-cart me-2"></i>Add to Cart
                        </button>` :
                        `<button class="btn btn-secondary w-100" disabled>Out of Stock</button>`
                    }
                </div>
            </div>
            <a href="product-detail.html?id=${product.id}" class="stretched-link product-link"></a>
        </div>
    `;
    
    colDiv.innerHTML = cardHTML;
    
    // Add click event to Add to Cart button that stops propagation
    const addToCartBtn = colDiv.querySelector('.add-to-cart-btn');
    if (addToCartBtn) {
        addToCartBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const productId = parseInt(this.dataset.productId);
            const success = addToCart(productId, 1);
            
            if (success) {
                // Show notification
                showNotification(`${product.name} added to cart!`, 'success');
            }
        });
    }
    
    // Add click event to favorite button
    const favoriteBtn = colDiv.querySelector('.favorite-btn');
    if (favoriteBtn) {
        favoriteBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const productId = parseInt(this.dataset.productId);
            const icon = this.querySelector('i');
            
            if (isProductFavorite(productId)) {
                removeFromFavorites(productId);
                icon.className = 'far fa-heart';
            } else {
                addToFavorites(productId);
                icon.className = 'fas fa-heart text-danger';
            }
        });
    }
    
    return colDiv;
}

function generateRatingStars(rating) {
    let starsHTML = '<div class="rating-stars">';
    
    // Full stars
    for (let i = 1; i <= Math.floor(rating); i++) {
        starsHTML += '<i class="fas fa-star filled"></i>';
    }
    
    // Half star
    if (rating % 1 >= 0.5) {
        starsHTML += '<i class="fas fa-star-half-alt filled"></i>';
    }
    
    // Empty stars
    for (let i = Math.ceil(rating); i < 5; i++) {
        starsHTML += '<i class="far fa-star empty"></i>';
    }
    
    starsHTML += '</div>';
    
    return starsHTML;
}

// At the end of the file, add this initialization for products.html
if (window.location.pathname.includes('products.html')) {
    document.addEventListener('DOMContentLoaded', function() {
        loadProductListing();
    });
} 