// Product data
const products = [
    {
        id: 1,
        name: "Apple iPhone 13 Pro",
        price: 119999.00,
        image: "img/products/product-1.jpg",
        category: "electronics",
        rating: 4.8,
        reviews: 256,
        description: "The iPhone 13 Pro features a 6.1-inch Super Retina XDR display with ProMotion, A15 Bionic chip, Pro camera system with 12MP telephoto, wide, and ultra-wide cameras, and up to 28 hours of video playback.",
        featured: true,
        inStock: true
    },
    {
        id: 2,
        name: "Samsung Galaxy S22 Ultra",
        price: 109999.00,
        image: "img/products/product-2.jpg",
        category: "electronics",
        rating: 4.7,
        reviews: 189,
        description: "The Galaxy S22 Ultra features a 6.8-inch Dynamic AMOLED 2X display, Snapdragon 8 Gen 1 processor, 108MP wide-angle camera, 12MP ultra-wide camera, two 10MP telephoto cameras, and a 5000mAh battery.",
        featured: true,
        inStock: true
    },
    {
        id: 3,
        name: "Sony WH-1000XM4 Wireless Noise-Canceling Headphones",
        price: 29999.00,
        image: "img/products/product-3.jpg",
        category: "electronics",
        rating: 4.9,
        reviews: 302,
        description: "Industry-leading noise cancellation with Dual Noise Sensor technology, up to 30-hour battery life, touch sensor controls, speak-to-chat technology, and wearing detection.",
        featured: true,
        inStock: true
    },
    {
        id: 4,
        name: "Apple MacBook Pro 14-inch",
        price: 199999.00,
        image: "img/products/product-4.jpg",
        category: "electronics",
        rating: 4.8,
        reviews: 143,
        description: "The 14-inch MacBook Pro features an M1 Pro chip, Liquid Retina XDR display, up to 17 hours of battery life, 1080p FaceTime HD camera, and a six-speaker sound system with force-cancelling woofers.",
        featured: false,
        inStock: true
    },
    {
        id: 5,
        name: "Nike Air Zoom Pegasus 38",
        price: 9999.00,
        image: "img/products/product-5.jpg",
        category: "fashion",
        rating: 4.6,
        reviews: 210,
        description: "The Nike Air Zoom Pegasus 38 is a versatile running shoe with a wider forefoot, breathable mesh upper, and Nike React foam for responsive cushioning.",
        featured: true,
        inStock: true
    },
    {
        id: 6,
        name: "Levi's 501 Original Fit Jeans",
        price: 4999.00,
        image: "img/products/product-6.jpg",
        category: "fashion",
        rating: 4.5,
        reviews: 178,
        description: "The iconic straight fit with signature button fly and authentic five-pocket styling. Made with heavyweight, durable denim.",
        featured: false,
        inStock: true
    },
    {
        id: 7,
        name: "Dyson V11 Absolute Cordless Vacuum",
        price: 44999.00,
        image: "img/products/dyson.jpeg",
        category: "home",
        rating: 4.7,
        reviews: 156,
        description: "Dyson's most intelligent cordless vacuum with automatic suction optimization, LCD screen display, and up to 60 minutes of run time.",
        featured: true,
        inStock: true
    },
    {
        id: 8,
        name: "Instant Pot Duo Plus 9-in-1 Electric Pressure Cooker",
        price: 12999.00,
        image: "img/products/product-8.jpg",
        category: "home",
        rating: 4.8,
        reviews: 312,
        description: "9-in-1 kitchen appliance: pressure cooker, slow cooker, rice cooker, steamer, sauté pan, yogurt maker, sterilizer, and food warmer. Cook up to 70% faster.",
        featured: false,
        inStock: true
    },
    {
        id: 9,
        name: "PlayStation 5 Console",
        price: 49999.00,
        image: "img/products/play-station.jpeg",
        category: "electronics",
        rating: 4.9,
        reviews: 267,
        description: "Experience lightning-fast loading, deeper immersion with the DualSense controller, and a library of breathtaking PS5 games.",
        featured: true,
        inStock: false
    },
    {
        id: 10,
        name: "Adidas Ultraboost 22",
        price: 15999.00,
        image: "img/products/product-10.jpg",
        category: "fashion",
        rating: 4.7,
        reviews: 198,
        description: "Experience incredible energy return with Adidas Boost technology, a Primeknit upper for a supportive fit, and a Continental Rubber outsole for superior traction.",
        featured: false,
        inStock: true
    },
    {
        id: 11,
        name: "Bose QuietComfort Earbuds",
        price: 26999.00,
        image: "img/products/product-11.jpg",
        category: "electronics",
        rating: 4.6,
        reviews: 143,
        description: "Noise-cancelling earbuds with high-fidelity audio, comfortable fit, sweat and weather resistance, and up to 6 hours of battery life.",
        featured: false,
        inStock: true
    },
    {
        id: 12,
        name: "KitchenAid Stand Mixer",
        price: 39999.00,
        image: "img/products/kitchen-aid-mixer.jpeg",
        category: "home",
        rating: 4.9,
        reviews: 287,
        description: "5-quart stainless steel mixing bowl, tilt-head design, 10 speeds for nearly any task, and a powerful motor for mixing tough ingredients.",
        featured: true,
        inStock: true
    }
];

// Function to get products by category
function getProductsByCategory(category) {
    if (category === 'all') {
        return products;
    } else {
        return products.filter(product => product.category === category);
    }
}

// Function to get featured products
function getFeaturedProducts() {
    return products.filter(product => product.featured);
}

// Function to get a single product by ID
function getProductById(id) {
    return products.find(product => product.id === parseInt(id));
}

// Function to get related products (same category, excluding the current product)
function getRelatedProducts(id, limit = 4) {
    const currentProduct = getProductById(id);
    if (!currentProduct) return [];
    
    return products
        .filter(product => product.category === currentProduct.category && product.id !== currentProduct.id)
        .slice(0, limit);
}

// Search products function
function searchProducts(query) {
    query = query.toLowerCase();
    return products.filter(product => 
        product.name.toLowerCase().includes(query) || 
        product.description.toLowerCase().includes(query) ||
        product.category.toLowerCase().includes(query)
    );
}

// Sort products function
function sortProducts(productsList, sortBy) {
    const productsCopy = [...productsList];
    
    switch(sortBy) {
        case 'price-low-high':
            return productsCopy.sort((a, b) => a.price - b.price);
        case 'price-high-low':
            return productsCopy.sort((a, b) => b.price - a.price);
        case 'rating':
            return productsCopy.sort((a, b) => b.rating - a.rating);
        case 'reviews':
            return productsCopy.sort((a, b) => b.reviews - a.reviews);
        default:
            return productsCopy;
    }
}

// Filter products by price range
function filterByPriceRange(productsList, min, max) {
    return productsList.filter(product => product.price >= min && product.price <= max);
}

// Filter products by rating
function filterByRating(productsList, minRating) {
    return productsList.filter(product => product.rating >= minRating);
}

// Filter products by availability
function filterByAvailability(productsList, inStockOnly) {
    if (!inStockOnly) return productsList;
    return productsList.filter(product => product.inStock);
} 